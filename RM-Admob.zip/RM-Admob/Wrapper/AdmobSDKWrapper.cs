using System.Collections;
using System.Collections.Generic;
using GoogleMobileAds.Api;
using RiseMediaSDK.Utils;
using UnityEngine;

public class AdmobSDKWrapper : IThirdPartySDKWrapper
{
    private bool isInitialized = false;
    public void Init(Dictionary<string, string> initParams)
    {
        MobileAds.RaiseAdEventsOnUnityMainThread = true;
        isInitialized = false;

        MobileAds.Initialize((InitializationStatus initStatus) =>
        {
            OnInit(initStatus);
        });

    }

    void OnInit(InitializationStatus initStatus)
    {
        UnityDebugLogsHelper.Log("Admob Initialized");
        isInitialized = true;
    }

    public void DeInit()
    {
         
    }

    public bool IsInitialized()
    {
        return isInitialized;
    }  
}
