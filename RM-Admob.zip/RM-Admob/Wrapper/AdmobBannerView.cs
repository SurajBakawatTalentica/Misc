using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using GoogleMobileAds.Api;
using RiseMediaSDK;
using RiseMediaSDK.Utils;

internal class AdmobBannerView : BaseBannerView
{
    public event Action<string, string> OnAdLoaded;
    public event Action<string, string, string> OnAdLoadFailed;
    public event Action<string, string> OnAdViewImpressionRecorded;
    public event Action<string, float, string> OnAdPaidEvent;

    GoogleMobileAds.Api.BannerView _bannerView; 
    string AdUnitId = string.Empty;

    public void ShowAd(Dictionary<string,string> adUnitInfo, RMBannerView bannerInfo)
    {
        if(DataManager.Instance.devicePlatform == RuntimePlatform.Android)
            AdUnitId = adUnitInfo["androidAdId"]; 
        else
            AdUnitId = adUnitInfo["iOSAdId"]; 

    #if UNITY_EDITOR
        AdUnitId = adUnitInfo["androidAdId"]; 
    #endif
    
        _bannerView = new GoogleMobileAds.Api.BannerView(AdUnitId, GetAdSize(bannerInfo), GetAdPosition(bannerInfo.placement));
        var adRequest = new GoogleMobileAds.Api.AdRequest();  // Build the request.
        _bannerView.LoadAd(adRequest);

        SubscribeEvents();
    }

    AdSize GetAdSize(RMBannerView bannerInfo)
    {
        var info = DataManager.Instance.QuerryForAdUnit(bannerInfo.AdUnitId);

        switch(info.w * info.h)
        {
            case 320 * 50:
            return AdSize.Banner;

            case 300 * 250:
            return AdSize.MediumRectangle;

            case 468 * 60:
            return AdSize.IABBanner;

            case 728 * 90:
            return AdSize.Leaderboard;

            default:
            return AdSize.Banner;
        }
    }

    AdPosition GetAdPosition(eBannerPlacement placement)
    {
        switch (placement)
        {
            case eBannerPlacement.Top:
                return AdPosition.Top;

            case eBannerPlacement.Bottom:
                return AdPosition.Bottom;

            case eBannerPlacement.Center:
                return AdPosition.Center;

            case eBannerPlacement.TopLeft:
                return AdPosition.TopLeft;

            case eBannerPlacement.TopRight:
                return AdPosition.TopRight;

            case eBannerPlacement.BottomLeft:
                return AdPosition.BottomLeft;

            case eBannerPlacement.BottomRight:
                return AdPosition.BottomRight;

            case eBannerPlacement.Left:
                return AdPosition.TopLeft;

            case eBannerPlacement.Right:
                return AdPosition.TopRight;

            default:
                return AdPosition.Top;
        }
    }

    
    public void HideAd()
    {
        if (_bannerView != null)
        {
            _bannerView.Destroy();
            _bannerView = null;
        }
    }

    public void Destroy()
    {
        UnsubscribeEvents();
    }

    public void SubscribeEvents()
    {
        _bannerView.OnBannerAdLoaded += AdLoadedHandler;
        _bannerView.OnBannerAdLoadFailed += AdFailedHandler;
        _bannerView.OnAdPaid += AdPaidHandler;
        _bannerView.OnAdImpressionRecorded += AdImpressionHandler;
        _bannerView.OnAdClicked += AdClickedHandler;
        _bannerView.OnAdFullScreenContentOpened += AdFullScreenContentOpenedHandler;
        _bannerView.OnAdFullScreenContentClosed += AdFullScreenContentClosedHandler;
    }

    public void UnsubscribeEvents()
    {
        if (_bannerView == null) return;

        _bannerView.OnBannerAdLoaded -= AdLoadedHandler;
        _bannerView.OnBannerAdLoadFailed -= AdFailedHandler;
        _bannerView.OnAdPaid -= AdPaidHandler;
        _bannerView.OnAdImpressionRecorded -= AdImpressionHandler;
        _bannerView.OnAdClicked -= AdClickedHandler;
        _bannerView.OnAdFullScreenContentOpened -= AdFullScreenContentOpenedHandler;
        _bannerView.OnAdFullScreenContentClosed -= AdFullScreenContentClosedHandler;
    }

    // Handlers
    private void AdLoadedHandler()
    {
        AdLoaded(AdUnitId);
        UnityDebugLogsHelper.Log("Banner view loaded an ad with response : " + _bannerView.GetResponseInfo());
    }

    private void AdFailedHandler(LoadAdError error)
    {
        AdFailed(AdUnitId, error.GetMessage());
        UnityDebugLogsHelper.LogError("Banner view failed to load an ad with error : " + error);
    }

    private void AdPaidHandler(AdValue adValue)
    {
        AdPaid(AdUnitId, adValue.Value);
        UnityDebugLogsHelper.Log(String.Format("Banner view paid {0} {1}.", adValue.Value, adValue.CurrencyCode));
    }

    private void AdImpressionHandler()
    {
        AdImpression(AdUnitId);
        UnityDebugLogsHelper.Log("Banner view recorded an impression.");
    }

    private void AdClickedHandler()
    {
        UnityDebugLogsHelper.Log("Banner view was clicked.");
    }

    private void AdFullScreenContentOpenedHandler()
    {
        UnityDebugLogsHelper.Log("Banner view full screen content opened.");
    }

    private void AdFullScreenContentClosedHandler()
    {
        UnityDebugLogsHelper.Log("Banner view full screen content closed.");
    }

    // Helper methods for raising events.
    void AdLoaded(string adUnitId)
    {
        //OnAdLoaded?.Invoke(adUnitId, ThirdPartySDK.Admob);
        OnAdLoaded?.Invoke(adUnitId, "Admob");

    }

    void AdFailed(string adUnitId, string error)
    {
        OnAdLoadFailed?.Invoke(adUnitId, error, "Admob");
    }

    void AdImpression(string adUnitId)
    {
        OnAdViewImpressionRecorded?.Invoke(adUnitId, "Admob");
    }

    void AdPaid(string adUnitId, float amount)
    {
        OnAdPaidEvent?.Invoke(adUnitId, amount, "Admob");
    }
}
