using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using GoogleMobileAds.Api;
using RiseMediaSDK;
using RiseMediaSDK.Utils;

internal class AdmobInterstitialView : BaseInterstitialView
{
    public event Action<string, string> OnAdLoaded;
    public event Action<string, string, string> OnAdLoadFailed;
    public event Action<string, string> OnAdViewImpressionRecorded;
    public event Action<string, float, string> OnAdPaidEvent;
    public event Action<string, string> OnAdClosed;


    GoogleMobileAds.Api.InterstitialAd _interstitialView; 
    string AdUnitId = string.Empty;

    public void ShowAd(Dictionary<string,string> adUnitInfo)
    {
        if(DataManager.Instance.devicePlatform == RuntimePlatform.Android)
            AdUnitId = adUnitInfo["androidAdId"]; 
        else
            AdUnitId = adUnitInfo["iOSAdId"]; 

    #if UNITY_EDITOR
        AdUnitId = adUnitInfo["androidAdId"]; 
    #endif

        var adRequest = new GoogleMobileAds.Api.AdRequest();  // Build the request.

        bool success = false;


        InterstitialAd.Load(AdUnitId, adRequest,
                (InterstitialAd ad, LoadAdError error) =>
                {
                    // if error is not null, the load request failed.
                    if (error != null || ad == null)
                    {
                        AdFailed(AdUnitId, "Load Error");
                        Debug.LogError("interstitial ad failed to load an ad " +
                                        "with error : " + error);
                        return;
                    }

                    Debug.Log("Interstitial ad loaded with response : "
                                + ad.GetResponseInfo());

                    _interstitialView = ad;

                    if (_interstitialView != null && _interstitialView.CanShowAd())
                    {
                        Debug.Log("Showing interstitial ad.");
                        _interstitialView.Show();
                        success = true;
                    }
                    else
                    {
                        AdFailed(AdUnitId, "Not Ready");
                        Debug.LogError("Interstitial ad is not ready yet.");
                        return;
                    }
                });

        if(success)
            SubscribeEvents();
    }

    public void Destroy()
    {
        UnsubscribeEvents();
    }

    public void SubscribeEvents()
    {
        _interstitialView.OnAdFullScreenContentOpened += AdLoadedHandler;
        _interstitialView.OnAdFullScreenContentClosed += AdClosedHandler;
        _interstitialView.OnAdFullScreenContentFailed += AdFailedHandler;
        _interstitialView.OnAdPaid += AdPaidHandler;
        _interstitialView.OnAdImpressionRecorded += AdImpressionHandler;
        _interstitialView.OnAdClicked += AdClickedHandler;
        _interstitialView.OnAdFullScreenContentOpened += AdFullScreenContentOpenedHandler;
        _interstitialView.OnAdFullScreenContentClosed += AdFullScreenContentClosedHandler;
    }

    public void UnsubscribeEvents()
    {
        if (_interstitialView == null) return;

        _interstitialView.OnAdFullScreenContentOpened -= AdLoadedHandler;
        _interstitialView.OnAdFullScreenContentClosed -= AdClosedHandler;
        _interstitialView.OnAdFullScreenContentFailed -= AdFailedHandler;
        _interstitialView.OnAdPaid -= AdPaidHandler;
        _interstitialView.OnAdImpressionRecorded -= AdImpressionHandler;
        _interstitialView.OnAdClicked -= AdClickedHandler;
        _interstitialView.OnAdFullScreenContentOpened -= AdFullScreenContentOpenedHandler;
        _interstitialView.OnAdFullScreenContentClosed -= AdFullScreenContentClosedHandler;
    }

    // Handlers
    private void AdLoadedHandler()
    {
        AdLoaded(AdUnitId);
        UnityDebugLogsHelper.Log("Interstitial view loaded an ad with response : " + _interstitialView.GetResponseInfo());
    }

    private void AdClosedHandler()
    {
        AdClosed(AdUnitId);
        UnityDebugLogsHelper.Log("Interstitial view closed an ad with response : " + _interstitialView.GetResponseInfo());
    }

    private void AdFailedHandler(GoogleMobileAds.Api.AdError error)
    {
        AdFailed(AdUnitId, error.GetMessage());
        UnityDebugLogsHelper.LogError("Interstitial view failed to load an ad with error : " + error);
    }

    private void AdPaidHandler(AdValue adValue)
    {
        AdPaid(AdUnitId, adValue.Value);
        UnityDebugLogsHelper.Log(String.Format("Interstitial view paid {0} {1}.", adValue.Value, adValue.CurrencyCode));
    }

    private void AdImpressionHandler()
    {
        AdImpression(AdUnitId);
        UnityDebugLogsHelper.Log("Interstitial view recorded an impression.");
    }

    private void AdClickedHandler()
    {
        UnityDebugLogsHelper.Log("Interstitial view was clicked.");
    }

    private void AdFullScreenContentOpenedHandler()
    {
        UnityDebugLogsHelper.Log("Interstitial view full screen content opened.");
    }

    private void AdFullScreenContentClosedHandler()
    {
        UnityDebugLogsHelper.Log("Interstitial view full screen content closed.");
    }

    // Helper methods for raising events.
    void AdLoaded(string adUnitId)
    {
        //OnAdLoaded?.Invoke(adUnitId, ThirdPartySDK.Admob);
        OnAdLoaded?.Invoke(adUnitId, "Admob");

    }

    void AdClosed(string adUnitID)
    {
        OnAdClosed?.Invoke(adUnitID, "Admob");
    }

    void AdFailed(string adUnitId, string error)
    {
        OnAdLoadFailed?.Invoke(adUnitId, error, "Admob");
    }

    void AdImpression(string adUnitId)
    {
        OnAdViewImpressionRecorded?.Invoke(adUnitId, "Admob");
    }

    void AdPaid(string adUnitId, float amount)
    {
        OnAdPaidEvent?.Invoke(adUnitId, amount, "Admob");
    }
}
